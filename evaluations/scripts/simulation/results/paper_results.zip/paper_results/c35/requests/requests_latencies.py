import pandas as pd
import matplotlib.pyplot as plt

# Set the default font size for all elements
plt.rcParams['font.size'] = 45

# Load the CSV files
cloud_df = pd.read_csv('output_metrics_cloud.csv')
edge_df = pd.read_csv('output_metrics_edge.csv')
hybrid_df = pd.read_csv('output_metrics_hybrid.csv')
oblique_df = pd.read_csv('output_metrics_oblique.csv')

# Filter the dataframes to only include requests with status_code=200
cloud_200 = cloud_df[cloud_df['status_code'] == 200]
edge_200 = edge_df[edge_df['status_code'] == 200]
hybrid_200 = hybrid_df[hybrid_df['status_code'] == 200]
oblique_200 = oblique_df[oblique_df['status_code'] == 200]

# Calculate the number of requests with status_code=200
cloud_requests = cloud_200.shape[0]
edge_requests = edge_200.shape[0]
hybrid_requests = hybrid_200.shape[0]
oblique_requests = oblique_200.shape[0]

# Calculate the average latency
cloud_latency_avg = cloud_200['latency'].mean()
edge_latency_avg = edge_200['latency'].mean()
hybrid_latency_avg = hybrid_200['latency'].mean()
oblique_latency_avg = oblique_200['latency'].mean()

# Create a DataFrame for plotting
plot_data = pd.DataFrame({
    'Deployment': ['Offload', 'Local', 'Local-Offload', 'ScaleWave'],
    'Requests': [cloud_requests, edge_requests, hybrid_requests, oblique_requests],
    'Average Latency': [cloud_latency_avg, edge_latency_avg, hybrid_latency_avg, oblique_latency_avg]
})

print(f'Requests: {[cloud_requests, edge_requests, hybrid_requests, oblique_requests]}, Average Latency: {[cloud_latency_avg, edge_latency_avg, hybrid_latency_avg, oblique_latency_avg]}')

# Plotting
fig, ax1 = plt.subplots(figsize=(18, 12))

# Plotting the number of requests
ax1.bar(plot_data['Deployment'], plot_data['Requests'], color='skyblue', alpha=0.6, label='Successful Requests')
#ax1.set_xlabel('Deployments', fontsize=45, labelpad=20)
ax1.set_ylabel('Successful Requests', color='skyblue', fontsize=45)
ax1.tick_params(axis='y', labelcolor='skyblue', labelsize=45)
ax1.tick_params(axis='x', rotation=15, labelsize=45)

# Creating a second y-axis to plot the average latency
ax2 = ax1.twinx()
ax2.plot(plot_data['Deployment'], plot_data['Average Latency'], color='orange', linewidth=4, marker='D', markersize=12, label='Average Latency')
ax2.set_ylabel('Average Latency (s)', color='orange', fontsize=45)
ax2.tick_params(axis='y', labelcolor='orange', labelsize=45)

# Title and adjusting legend position
fig.tight_layout()
#fig.legend(loc="upper center", bbox_to_anchor=(0.5, 1.1), fontsize=28)

# Display grid
plt.grid(True)

# Save the figure before showing it in very high quality
plt.savefig('successful_requests_c35_cp.png', dpi=400, bbox_inches='tight')

# Display the plot
plt.show()
