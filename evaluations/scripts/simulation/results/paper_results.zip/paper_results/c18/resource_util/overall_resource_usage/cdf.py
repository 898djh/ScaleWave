import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline

# Load the data from CSV files
cloud_df = pd.read_csv('overall_resource_usage_cloud.csv')
edge_df = pd.read_csv('overall_resource_usage_edge.csv')
hybrid_df = pd.read_csv('overall_resource_usage_hybrid.csv')
oblique_df = pd.read_csv('overall_resource_usage_oblique.csv')

# Define resources to plot
resources = [
    'Overall CPU Usage (%)',
    'Overall Memory Usage (%)',
    'Overall Disk Read (bytes/s)',
    'Overall Disk Write (bytes/s)',
    'Overall Network Upload (bytes/s)',
    'Overall Network Download (bytes/s)',
    'Overall GPU Usage (%)',
    'Overall GPU Memory Used (MB)'
]

# Define labels for the deployments
labels = ['Cloud', 'Edge', 'Edge-Cloud', 'Oblique']

# Define updated colors for the lines, including green for Cloud
updated_colors = ['#00FF00', '#FF69B4', '#FFA500', '#87CEEB']  # Green, HotPink, Orange, SkyBlue

# Function to plot smooth CDF with custom colors and grid
def plot_smooth_cdf(data, labels, resource_name, colors):
    plt.figure(figsize=(10, 6))
    for df, label, color in zip(data, labels, colors):
        # Calculate CDF
        values = np.sort(df[resource_name])
        cdf = np.arange(1, len(values) + 1) / len(values)
        
        # Make the curve smooth
        try:
            spline = make_interp_spline(values, cdf)
            smooth_values = np.linspace(values.min(), values.max(), 500)
            smooth_cdf = spline(smooth_values)
            plt.plot(smooth_values, smooth_cdf, label=label, color=color)
        except Exception as e:
            # In case of an error with interpolation, plot the original CDF
            plt.plot(values, cdf, label=label, color=color)
    
    plt.title(f'CDF of {resource_name}')
    plt.xlabel(resource_name)
    plt.ylabel('CDF')
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.legend()
    plt.tight_layout()
    fig_name = resource_name.lower().replace(' ', '_').replace('(%)', '').replace('(bytes/s)', '').replace('(mb)', '') + "cdf"
    plt.savefig(f'{fig_name}.png')
    plt.show()

# Plot smooth CDF for each resource with updated colors
for resource in resources:
    data = [cloud_df, edge_df, hybrid_df, oblique_df]
    plot_smooth_cdf(data, labels, resource, updated_colors)

